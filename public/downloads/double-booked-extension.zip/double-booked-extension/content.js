/* Double-Booked — Otto coach schedule-conflict finder.
 * Runs in the page's own context (manifest world:MAIN) on vsa.ottosport.ai, so every
 * request is same-origin with your live login — no token pasting, no CORS, no refresh dance.
 */
(function () {
  "use strict";

  // ---------------------------------------------------------------- live-token capture
  // The dii_ua cookie holds a short-lived token the app silently refreshes, so replaying
  // it is unreliable. Instead we watch the app's own requests to /_api and reuse the exact,
  // currently-valid Authorization header it sends. Installed at document_start (before the
  // app's scripts run) so we catch its very first authenticated call.
  var DB_VERSION = "0.7.0-travel-threshold";
  var TEAM_NAMES = {};
  var LIVE_AUTH = null;
  var CAPTURE_LOG = [];
  var STATS = { fetchCalls: 0, xhrOpens: 0, apiReqs: [], mainWorld: false };
  (function installInterceptors() {
    try { STATS.mainWorld = (typeof chrome === "undefined") || !chrome.runtime || !chrome.runtime.id; } catch (e) { STATS.mainWorld = true; }
    function hdrGet(h, name) {
      if (!h) return null;
      name = name.toLowerCase();
      try { if (typeof h.get === "function") { const v = h.get(name); if (v) return v; } } catch (e) {}
      if (Array.isArray(h)) { for (var i = 0; i < h.length; i++) { if (String(h[i][0]).toLowerCase() === name) return h[i][1]; } return null; }
      for (var k in h) { if (Object.prototype.hasOwnProperty.call(h, k) && k.toLowerCase() === name) return h[k]; }
      return null;
    }
    function hdrNames(h) {
      const out = [];
      if (!h) return out;
      try { if (typeof h.forEach === "function" && typeof h.get === "function") { h.forEach(function (v, k) { out.push(k); }); return out; } } catch (e) {}
      if (Array.isArray(h)) { h.forEach(function (p) { out.push(p[0]); }); return out; }
      for (var k in h) { if (Object.prototype.hasOwnProperty.call(h, k)) out.push(k); }
      return out;
    }
    function recordAuth(a, source) {
      try {
        if (!a) return;                       // capture ANY Authorization scheme, verbatim (Otto's isn't "Bearer")
        LIVE_AUTH = a;
        var raw = a.indexOf(" ") > 0 ? a.slice(a.indexOf(" ") + 1) : a;
        var exp = jwtExpMs(raw);
        CAPTURE_LOG.push({ source: source, expMin: exp ? Math.round((exp - Date.now()) / 60000) : null, at: new Date().toLocaleTimeString() });
        if (CAPTURE_LOG.length > 60) CAPTURE_LOG.shift();
      } catch (e) {}
    }
    function logApi(t, headerNames, hasAuth) {
      STATS.apiReqs.push({ t: t, headers: headerNames, hasAuth: hasAuth });
      if (STATS.apiReqs.length > 60) STATS.apiReqs.shift();
    }
    try {
      const _fetch = window.fetch;
      if (_fetch && !_fetch.__dbPatched) {
        const patched = function (input, init) {
          STATS.fetchCalls++;
          if (!(init && init.__dbSelf)) {
            const url = typeof input === "string" ? input : (input && input.url);
            const headers = (init && init.headers) || (typeof input !== "string" && input && input.headers);
            if (url && String(url).indexOf("/_api") !== -1) {
              const a = hdrGet(headers, "authorization");
              logApi("fetch", hdrNames(headers), !!a);
              recordAuth(a, "fetch");
            }
          }
          return _fetch.apply(this, arguments);
        };
        patched.__dbPatched = true;
        window.fetch = patched;
      }
    } catch (e) {}
    try {
      const XP = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
      if (XP && !XP.__dbPatched) {
        const _open = XP.open, _srh = XP.setRequestHeader, _send = XP.send;
        XP.open = function (m, u) { this.__dbUrl = u; this.__dbHeaders = []; STATS.xhrOpens++; return _open.apply(this, arguments); };
        XP.setRequestHeader = function (k, v) {
          try {
            if (this.__dbHeaders) this.__dbHeaders.push(k);
            if (/^authorization$/i.test(k) && this.__dbUrl && String(this.__dbUrl).indexOf("/_api") !== -1) recordAuth(v, "xhr");
          } catch (e) {}
          return _srh.apply(this, arguments);
        };
        XP.send = function () {
          try {
            if (this.__dbUrl && String(this.__dbUrl).indexOf("/_api") !== -1) {
              const names = this.__dbHeaders || [];
              logApi("xhr", names, names.some(function (h) { return /^authorization$/i.test(h); }));
            }
          } catch (e) {}
          return _send.apply(this, arguments);
        };
        XP.__dbPatched = true;
      }
    } catch (e) {}
  })();

  if (window.__doubleBooked__) { window.__doubleBooked__.open(); return; }

  // ---------------------------------------------------------------- config
  const API = "/_api";
  const TZ = "America/New_York";
  // Your teams pre-filled so it works even if auto-detect finds nothing. Edit freely.
  const DEFAULT_TEAM_IDS = ["6a15d9cbbf8176044709ef83", "6a15d9cabf8176044709eeed"];
  const COACH_ROLE_RE = /coach|trainer|manager/i;

  const Q_BYTYPE =
    "query teamSchedulesByType($seasonalTeamId: ObjectID!){ teamSchedulesByType(seasonalTeamId:$seasonalTeamId){ __typename ... on Game { _id homeTeamId awayTeamId homeTeamName awayTeamName event{ startDateTime duration status venue{ name clientLocation{ name } } } } ... on TrainingActivity { _id event{ startDateTime duration status venue{ name clientLocation{ name } } } } } }";
  const Q_GAMES =
    "query teamSchedules($seasonalTeamId: ObjectID!){ teamSchedules(seasonalTeamId:$seasonalTeamId){ _id homeTeamId awayTeamId homeTeamName awayTeamName event{ startDateTime duration status venue{ name clientLocation{ name } } } } }";
  const Q_STAFF =
    "query SeasonalTeamStaff($id: ObjectID!){ seasonalTeam(id:$id){ _id name ageGroup gender staff{ _id type rosterData{ role status } person{ _id firstName lastName } } } }";
  const Q_TEAM =
    "query seasonalTeamMeta($id: ObjectID!){ seasonalTeam(id:$id){ _id name ageGroup gender season{ _id } } }";
  const Q_SEASON_TEAMS =
    "query seasonalTeams($seasonId: ObjectID!){ seasonalTeams(seasonId:$seasonId){ _id name } }";

  // ---------------------------------------------------------------- auth
  function cookieValues(name) {
    const out = [];
    (document.cookie || "").split("; ").forEach(function (p) {
      const i = p.indexOf("=");
      if (i > 0 && p.slice(0, i) === name) out.push(p.slice(i + 1));
    });
    return out;
  }
  function b64url(s) {
    s = String(s).replace(/-/g, "+").replace(/_/g, "/");
    while (s.length % 4) s += "=";
    try { return atob(s); } catch (e) { return ""; }
  }
  function jwtExpMs(tok) {
    try { const j = JSON.parse(b64url(String(tok).split(".")[1])); return j && j.exp ? j.exp * 1000 : null; }
    catch (e) { return null; }
  }
  // Returns { token, exp } for the freshest dii_ua cookie, or null.
  function getToken() {
    const cands = cookieValues("dii_ua").map(function (v) {
      try { const t = (JSON.parse(decodeURIComponent(v)) || {}).token; return t ? { token: t, exp: jwtExpMs(t) } : null; }
      catch (e) { return null; }
    }).filter(Boolean);
    if (!cands.length) return null;
    cands.sort(function (a, b) { return (b.exp || 0) - (a.exp || 0); });
    return cands[0];
  }

  async function gql(query, variables, opName) {
    // Prefer the app's live captured token; fall back to the (possibly stale) cookie token.
    let auth = LIVE_AUTH;
    if (!auth) { const tok = getToken(); if (tok) auth = "Bearer " + tok.token; }
    if (!auth) throw new Error("NO_LIVE_TOKEN");
    const r = await fetch(API, {
      method: "POST",
      credentials: "include",
      __dbSelf: true,
      headers: {
        "content-type": "application/json",
        "accept": "application/json",
        "authorization": auth,
        "Apollo-Require-Preflight": "true"
      },
      body: JSON.stringify({ operationName: opName || null, query: query, variables: variables })
    });
    const text = await r.text();
    let j;
    try { j = JSON.parse(text); }
    catch (e) { throw new Error("HTTP " + r.status + " (non-JSON): " + text.slice(0, 200)); }
    if (j.errors) {
      const msg = JSON.stringify(j.errors);
      if (/session expired|UNAUTHENTICATED|Not Authenticated/i.test(msg)) throw new Error("SESSION_EXPIRED");
      throw new Error(msg.slice(0, 300));
    }
    return j.data;
  }

  // ---------------------------------------------------------------- discovery
  // Harvest seasonal-team ids that Otto has already rendered anywhere on the page.
  function scrapeTeamIds() {
    const ids = new Set();
    const html = document.documentElement ? document.documentElement.innerHTML : "";
    const re = /_teams\/team\/([a-f0-9]{24})/g;
    let m;
    while ((m = re.exec(html))) ids.add(m[1]);
    return [...ids];
  }

  // ---------------------------------------------------------------- fetch layer
  async function fetchSchedule(id) {
    let rows = null, note = null;
    try { rows = (await gql(Q_BYTYPE, { seasonalTeamId: id }, "teamSchedulesByType")).teamSchedulesByType; }
    catch (e) {
      if (e.message === "SESSION_EXPIRED" || e.message === "NOT_LOGGED_IN") throw e;
      note = "games-only (byType: " + e.message + ")";
      try { rows = ((await gql(Q_GAMES, { seasonalTeamId: id }, "teamSchedules")).teamSchedules || []).map(function (g) { return Object.assign({ __typename: "Game" }, g); }); }
      catch (e2) { if (e2.message === "SESSION_EXPIRED" || e2.message === "NOT_LOGGED_IN") throw e2; throw new Error("schedule failed: " + e2.message); }
    }
    const events = [];
    let teamName = null;
    (rows || []).forEach(function (row) {
      const ev = row.event || {};
      if (!ev.startDateTime) return;
      const isGame = row.__typename === "Game";
      let tName = null, opponent = null;
      if (isGame) {
        const home = row.homeTeamId === id;
        tName = home ? row.homeTeamName : row.awayTeamName;
        opponent = home ? row.awayTeamName : row.homeTeamName;
        if (tName) teamName = tName;
      }
      const field = ev.venue && ev.venue.name;                                   // e.g. "1B"
      const park = ev.venue && ev.venue.clientLocation && ev.venue.clientLocation.name; // e.g. "James S Long Park"
      const venueDisplay = park ? (field ? park + " (" + field + ")" : park) : (field || "");
      const venueKey = (park || field || "").toString().trim().toLowerCase();    // travel keyed on the PARK, not the field
      events.push({
        type: isGame ? "game" : "training",
        teamId: id, teamName: tName, opponent: opponent,
        start: ev.startDateTime, durationMin: ev.duration || null,
        venue: venueDisplay, venueKey: venueKey,
        status: ev.status, gameId: row._id
      });
    });
    events.forEach(function (e) { if (!e.teamName) e.teamName = teamName || id; });
    return { events: events, teamName: teamName, note: note };
  }

  async function fetchStaff(id) {
    try {
      const t = (await gql(Q_STAFF, { id: id }, "SeasonalTeamStaff")).seasonalTeam;
      if (!t) return { teamName: null, coaches: [] };
      const coaches = (t.staff || []).map(function (s) {
        const role = (s.rosterData && s.rosterData.role) || s.type || "";
        const p = s.person || {};
        const name = ((p.firstName || "") + " " + (p.lastName || "")).trim();
        return { personId: p._id || name, name: name || "Unnamed", role: role };
      }).filter(function (c) { return c.name && c.name !== "Unnamed"; });
      return { teamName: t.name || null, coaches: coaches };
    } catch (e) {
      if (e.message === "SESSION_EXPIRED" || e.message === "NOT_LOGGED_IN") throw e;
      return { teamName: null, coaches: [], note: "staff failed: " + e.message };
    }
  }

  async function fetchTeamMeta(id) {
    try {
      const t = (await gql(Q_TEAM, { id: id }, "seasonalTeamMeta")).seasonalTeam;
      if (t) { if (t.name) TEAM_NAMES[id] = t.name; return { name: t.name || null, seasonId: t.season && t.season._id }; }
    } catch (e) { if (e.message === "SESSION_EXPIRED" || e.message === "NOT_LOGGED_IN") throw e; }
    return { name: null, seasonId: null };
  }

  // From one known team → its season → every team in that season (for the director).
  async function enumerateSeasonTeams(fromId) {
    const meta = await fetchTeamMeta(fromId);
    if (!meta.seasonId) throw new Error("couldn't find the season for that team");
    const d = await gql(Q_SEASON_TEAMS, { seasonId: meta.seasonId }, "seasonalTeams");
    const list = (d.seasonalTeams || []).map(function (t) { return { id: t._id, name: t.name }; });
    list.forEach(function (t) { if (t.name) TEAM_NAMES[t.id] = t.name; });
    return list;
  }

  // Limited-concurrency map.
  async function pool(items, limit, worker, onProgress) {
    const results = new Array(items.length);
    let i = 0, done = 0;
    async function run() {
      while (i < items.length) {
        const idx = i++;
        try { results[idx] = await worker(items[idx], idx); }
        catch (e) { results[idx] = { __error: e }; if (e.message === "SESSION_EXPIRED" || e.message === "NOT_LOGGED_IN") throw e; }
        done++;
        if (onProgress) onProgress(done, items.length);
      }
    }
    const runners = [];
    for (let k = 0; k < Math.min(limit, items.length); k++) runners.push(run());
    await Promise.all(runners);
    return results;
  }

  // Pull schedules + staff for a set of teams; build the normalized dataset.
  async function collect(teamIds, opts, onProgress) {
    const withCoaches = opts.byCoach;
    const teams = [], events = [], notes = [];
    const nameById = {};
    const coachMap = {}; // personId -> {id,name,teamIds:Set,roles:Set}

    await pool(teamIds, 5, async function (id) {
      const sched = await fetchSchedule(id);
      if (sched.note) notes.push(id + ": " + sched.note);
      sched.events.forEach(function (e) { events.push(e); });
      if (sched.teamName) nameById[id] = sched.teamName;

      if (withCoaches) {
        const st = await fetchStaff(id);
        if (st.note) notes.push(id + ": " + st.note);
        if (st.teamName) nameById[id] = st.teamName;
        (st.coaches || []).forEach(function (c) {
          const key = c.personId;
          if (!coachMap[key]) coachMap[key] = { id: key, name: c.name, teamIds: new Set(), roles: new Set() };
          coachMap[key].teamIds.add(id);
          if (c.role) coachMap[key].roles.add(c.role);
        });
      }
      // Guarantee a human-readable name even for training-only teams with no game/staff name.
      if (!nameById[id]) {
        if (TEAM_NAMES[id]) nameById[id] = TEAM_NAMES[id];
        else { const m = await fetchTeamMeta(id); if (m.name) nameById[id] = m.name; }
      }
    }, onProgress);

    teamIds.forEach(function (id) { teams.push({ id: id, name: nameById[id] || id }); });
    // backfill training rows' team names
    events.forEach(function (e) { if (!e.teamName || e.teamName === e.teamId) e.teamName = nameById[e.teamId] || e.teamId; });

    let coaches = null;
    if (withCoaches) {
      const list = Object.keys(coachMap).map(function (k) {
        const c = coachMap[k];
        const roles = [...c.roles];
        const isCoach = roles.some(function (r) { return COACH_ROLE_RE.test(r); });
        return { id: c.id, name: c.name, teamIds: [...c.teamIds], roles: roles, isCoach: isCoach };
      });
      // Prefer coach-type staff; if some teams have coach-typed people, drop pure non-coaches to cut noise.
      const anyCoach = list.some(function (c) { return c.isCoach; });
      coaches = anyCoach ? list.filter(function (c) { return c.isCoach; }) : list;
    }
    return { teams: teams, events: events, coaches: coaches, notes: notes };
  }

  // ---------------------------------------------------------------- conflict engine
  const fmtDay = new Intl.DateTimeFormat("en-US", { timeZone: TZ, weekday: "short", month: "short", day: "numeric" });
  const fmtDayKey = new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" });
  const fmtTime = new Intl.DateTimeFormat("en-US", { timeZone: TZ, hour: "numeric", minute: "2-digit" });

  function parseEvents(data, cfg) {
    const teamName = {};
    (data.teams || []).forEach(function (t) { teamName[t.id] = t.name; });
    const out = [];
    (data.events || []).forEach(function (e, i) {
      const t = new Date(e.start);
      if (isNaN(t)) return;
      const dur = (e.durationMin != null && e.durationMin > 0) ? e.durationMin : (e.type === "training" ? cfg.trainLen : cfg.gameLen);
      out.push({
        idx: i, type: e.type === "training" ? "training" : "game",
        teamId: e.teamId, teamName: e.teamName || teamName[e.teamId] || e.teamId, opponent: e.opponent || null,
        startMs: t.getTime(), endMs: t.getTime() + dur * 60000, durationMin: dur,
        venue: (e.venue || "").trim(), venueKey: (e.venueKey || e.venue || "").toString().trim().toLowerCase(),
        gameId: e.gameId != null ? String(e.gameId) : ("i" + i), dayKey: fmtDayKey.format(t)
      });
    });
    return out;
  }
  function buildCoaches(data) {
    if (Array.isArray(data.coaches) && data.coaches.length) {
      return data.coaches.map(function (c) { return { id: c.id || c.name, name: c.name || "Unnamed", teamIds: (c.teamIds || []).map(String), roles: c.roles || [] }; });
    }
    const ids = (data.teams || []).map(function (t) { return String(t.id); });
    const evIds = new Set((data.events || []).map(function (e) { return String(e.teamId); }));
    evIds.forEach(function (id) { if (ids.indexOf(id) < 0) ids.push(id); });
    return [{ id: "__self", name: "Your teams", teamIds: ids, implicit: true }];
  }
  function analyze(data, cfg) {
    const evs = parseEvents(data, cfg);
    const byTeam = {};
    evs.forEach(function (e) { (byTeam[e.teamId] = byTeam[e.teamId] || []).push(e); });
    const coaches = buildCoaches(data);
    const result = coaches.map(function (c) {
      const seen = new Set(); const mine = [];
      c.teamIds.forEach(function (tid) {
        (byTeam[tid] || []).forEach(function (e) { const k = e.gameId + "@" + e.teamId; if (seen.has(k)) return; seen.add(k); mine.push(e); });
      });
      mine.sort(function (a, b) { return a.startMs - b.startMs; });
      const conflicts = [];
      for (let i = 0; i < mine.length; i++) {
        for (let j = i + 1; j < mine.length; j++) {
          const a = mine[i], b = mine[j];
          if (a.dayKey !== b.dayKey) continue;
          if (a.gameId === b.gameId) continue;
          const overlap = a.startMs < b.endMs && b.startMs < a.endMs;
          if (overlap) {
            conflicts.push({ sev: "crit", kind: "overlap", a: a, b: b, note: a.venueKey === b.venueKey ? "Two teams at the same time" : "Two teams at once, in different places" });
          } else {
            const gapMin = Math.round((b.startMs - a.endMs) / 60000);
            if (a.venueKey && b.venueKey && a.venueKey !== b.venueKey && gapMin <= cfg.buffer) {
              conflicts.push({ sev: "warn", kind: "travel", a: a, b: b, gapMin: gapMin, note: gapMin <= 0 ? "No time to travel between parks" : "Only " + gapMin + " min to change parks" });
            }
          }
        }
      }
      const crit = conflicts.filter(function (x) { return x.sev === "crit"; }).length;
      const warn = conflicts.filter(function (x) { return x.sev === "warn"; }).length;
      return { coach: c, events: mine, conflicts: conflicts, crit: crit, warn: warn };
    });
    result.sort(function (x, y) { return (y.crit - x.crit) || (y.warn - x.warn) || x.coach.name.localeCompare(y.coach.name); });
    return { result: result, totalEvents: evs.length };
  }

  // ---------------------------------------------------------------- UI
  const CSS = `
  :host{ all: initial; }
  *{ box-sizing:border-box; font-family: ui-sans-serif,-apple-system,"Segoe UI",Roboto,sans-serif; }
  .launch{ position:fixed; right:18px; bottom:18px; z-index:2147483000; display:inline-flex; align-items:center; gap:8px;
    background:#2f7d46; color:#fff; border:none; border-radius:24px; padding:11px 16px; font-size:14px; font-weight:700;
    box-shadow:0 6px 20px -6px rgba(0,0,0,.5); cursor:pointer; }
  .launch:hover{ background:#265f37; }
  .overlay{ position:fixed; inset:0; z-index:2147483001; background:rgba(10,14,9,.42); display:none; }
  .overlay.on{ display:block; }
  .panel{ position:fixed; top:0; right:0; height:100%; width:min(560px,100%); background:#f4f6f1; color:#15190f;
    box-shadow:-10px 0 40px -12px rgba(0,0,0,.5); display:flex; flex-direction:column; }
  .ph{ display:flex; align-items:center; gap:10px; padding:14px 16px; background:#fff; border-bottom:1px solid #dfe3d8; }
  .ph .mark{ width:30px;height:30px;border-radius:8px;background:linear-gradient(150deg,#2f7d46,#1d5a30);display:grid;place-items:center;color:#fff;font-size:16px;}
  .ph h1{ font-size:16px; font-weight:800; margin:0; letter-spacing:-.01em; }
  .ph .x{ margin-left:auto; background:none;border:none;font-size:22px;line-height:1;color:#5a6150;cursor:pointer;padding:4px 8px;border-radius:6px;}
  .ph .x:hover{ background:#eef1ea; }
  .body{ overflow:auto; padding:16px; flex:1; }
  .card{ background:#fff;border:1px solid #dfe3d8;border-radius:11px;padding:14px;margin-bottom:12px; }
  label.lab{ display:block;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#5a6150;margin-bottom:6px;}
  textarea{ width:100%;min-height:66px;resize:vertical;border:1px solid #cdd2c2;border-radius:8px;background:#eef1ea;
    color:#15190f;font-family:ui-monospace,Menlo,monospace;font-size:12px;line-height:1.5;padding:9px; }
  .row{ display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px; }
  .btn{ border:1px solid #cdd2c2;background:#fff;color:#15190f;border-radius:8px;padding:8px 13px;font-size:13px;font-weight:600;cursor:pointer; }
  .btn:hover{ background:#eef1ea; }
  .btn.primary{ background:#2f7d46;border-color:#2f7d46;color:#fff; }
  .btn.primary:hover{ background:#265f37; }
  .btn:disabled{ opacity:.55; cursor:default; }
  .mode{ display:inline-flex;border:1px solid #cdd2c2;border-radius:8px;overflow:hidden;margin-bottom:10px; }
  .mode button{ border:none;background:#fff;padding:7px 12px;font-size:12.5px;font-weight:600;cursor:pointer;color:#5a6150; }
  .mode button.on{ background:#2f7d46;color:#fff; }
  .nums{ display:flex;gap:14px;flex-wrap:wrap; }
  .num{ display:flex;flex-direction:column;gap:4px; }
  .num small{ font-size:10.5px;color:#868d79; }
  .num input{ width:84px;font-family:ui-monospace,monospace;font-size:13px;padding:7px 9px;border:1px solid #cdd2c2;border-radius:7px;background:#fff;color:#15190f; }
  .prog{ font-size:12.5px;color:#5a6150;font-family:ui-monospace,monospace;margin-top:8px;min-height:16px; }
  .err{ background:#fbeae7;border:1px solid #c23a2b;color:#8f2a20;border-radius:8px;padding:10px 12px;font-size:13px;margin-bottom:12px; }
  .tiles{ display:grid;grid-template-columns:repeat(auto-fit,minmax(96px,1fr));gap:8px;margin:4px 0 14px; }
  .tile{ background:#fff;border:1px solid #dfe3d8;border-radius:10px;padding:10px 12px; }
  .tile .k{ font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:#5a6150;font-weight:700; }
  .tile .v{ font-size:24px;font-weight:800;line-height:1.1;margin-top:3px;font-variant-numeric:tabular-nums; }
  .tile.crit{ background:#fbeae7;border-color:transparent;} .tile.crit .v,.tile.crit .k{color:#8f2a20;}
  .tile.warn{ background:#f8efdc;border-color:transparent;} .tile.warn .v,.tile.warn .k{color:#7c5205;}
  .tile.good .v{ color:#2f7d46; }
  details.coach{ background:#fff;border:1px solid #dfe3d8;border-radius:11px;margin-bottom:9px;overflow:hidden; }
  details.coach>summary{ list-style:none;cursor:pointer;display:flex;align-items:center;gap:10px;padding:12px 13px; }
  details.coach>summary::-webkit-details-marker{ display:none; }
  .stripe{ width:5px;align-self:stretch;border-radius:3px;background:#cdd2c2;margin:-12px 2px -12px -4px; }
  .coach.hc .stripe{ background:#c23a2b; } .coach.hw .stripe{ background:#a9700a; }
  .cn{ font-weight:700;font-size:14px; } .roles{ font-size:11px;color:#868d79; }
  .ct{ color:#5a6150;font-size:12px;margin-top:2px; } .ct .tm{ font-family:ui-monospace,monospace;font-size:11px;background:#eef1ea;padding:1px 5px;border-radius:4px;margin-right:4px;display:inline-block; }
  .sm{ flex:1;min-width:0; }
  .badge{ font-family:ui-monospace,monospace;font-size:11px;font-weight:700;padding:3px 8px;border-radius:14px;white-space:nowrap; }
  .badge.crit{ background:#fbeae7;color:#8f2a20; } .badge.warn{ background:#f8efdc;color:#7c5205; }
  .cbody{ padding:2px 13px 12px 18px;border-top:1px solid #dfe3d8; }
  .cf{ padding:11px 0;border-bottom:1px dashed #dfe3d8; } .cf:last-child{ border-bottom:none; }
  .cf .t{ font-weight:700;font-size:13px; } .cf.crit .t{ color:#8f2a20; } .cf.warn .t{ color:#7c5205; }
  .cf .when{ font-family:ui-monospace,monospace;font-size:11px;color:#868d79;margin-top:1px; }
  .g{ background:#eef1ea;border:1px solid #dfe3d8;border-radius:8px;padding:8px 10px;margin-top:7px;display:grid;grid-template-columns:auto 1fr;gap:2px 10px;align-items:baseline; }
  .g .gt{ font-family:ui-monospace,monospace;font-size:12px;font-weight:700;white-space:nowrap;font-variant-numeric:tabular-nums; }
  .g .gm{ font-size:13px; } .g .gm b{ font-weight:700; } .g .gm .opp{ color:#868d79; }
  .g .typ{ font-family:ui-monospace,monospace;font-size:9.5px;text-transform:uppercase;letter-spacing:.05em;padding:1px 5px;border-radius:4px;background:#fff;border:1px solid #dfe3d8;color:#868d79;margin-left:6px; }
  .g .gv{ grid-column:2;color:#5a6150;font-size:12px; }
  .gap{ grid-column:1 / -1;margin-top:4px;font-family:ui-monospace,monospace;font-size:11px;font-weight:700; }
  .cf.crit .gap{ color:#8f2a20; } .cf.warn .gap{ color:#7c5205; }
  .empty{ text-align:center;padding:34px 16px;color:#5a6150; } .empty .big{ font-size:34px; } .empty h3{ margin:6px 0 2px;color:#15190f;font-size:17px; }
  .hd{ font-size:15px;font-weight:800;margin:2px 0 10px; }
  .hint{ font-size:12px;color:#868d79;margin-top:6px;line-height:1.5; }
  `;

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (m) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[m]; }); }

  const App = (function () {
    let host, root, overlay, els = {}, state = { mode: "mine", busy: false, cfg: { buffer: 30, gameLen: 50, trainLen: 60 } };

    function mount() {
      host = document.createElement("div");
      host.id = "double-booked-host";
      root = host.attachShadow({ mode: "open" });
      const style = document.createElement("style"); style.textContent = CSS; root.appendChild(style);

      const launch = document.createElement("button");
      launch.className = "launch"; launch.innerHTML = "&#9917; Conflicts";
      launch.addEventListener("click", open);
      root.appendChild(launch);

      overlay = document.createElement("div"); overlay.className = "overlay";
      overlay.addEventListener("click", function (e) { if (e.target === overlay) close(); });
      overlay.innerHTML = panelHTML();
      root.appendChild(overlay);
      document.documentElement.appendChild(host);

      els.close = root.querySelector(".x");
      els.teams = root.querySelector("#dbTeams");
      els.detect = root.querySelector("#dbDetect");
      els.scan = root.querySelector("#dbScan");
      els.season = root.querySelector("#dbSeason");
      els.run = root.querySelector("#dbRun");
      els.refresh = root.querySelector("#dbRefresh");
      els.diag = root.querySelector("#dbDiag");
      els.email = root.querySelector("#dbEmail");
      els.prog = root.querySelector("#dbProg");
      els.results = root.querySelector("#dbResults");
      els.buffer = root.querySelector("#dbBuffer");
      els.gameLen = root.querySelector("#dbGameLen");
      els.trainLen = root.querySelector("#dbTrainLen");
      els.modeMine = root.querySelector("#dbModeMine");
      els.modeClub = root.querySelector("#dbModeClub");

      els.close.addEventListener("click", close);
      els.detect.addEventListener("click", onDetect);
      els.scan.addEventListener("click", onScan);
      els.season.addEventListener("click", onListSeason);
      els.run.addEventListener("click", function () { runNow(); });
      els.refresh.addEventListener("click", function () { runNow(); });
      els.diag.addEventListener("click", function () { runDiag(); });
      els.email.addEventListener("click", function () { onEmail(); });
      els.modeMine.addEventListener("click", function () { setMode("mine"); });
      els.modeClub.addEventListener("click", function () { setMode("club"); });

      els.teams.value = DEFAULT_TEAM_IDS.join("\n");
      setMode("mine");
    }

    function panelHTML() {
      return `<aside class="panel" role="dialog" aria-label="Double-Booked">
        <div class="ph"><span class="mark">&#9917;</span><h1>Double-Booked</h1><button class="x" title="Close">&times;</button></div>
        <div class="body">
          <div class="card">
            <div class="mode">
              <button id="dbModeMine" class="on">My teams</button>
              <button id="dbModeClub">Whole club (by coach)</button>
            </div>
            <label class="lab" for="dbTeams">Seasonal team IDs (one per line)</label>
            <textarea id="dbTeams" spellcheck="false"></textarea>
            <div class="row">
              <button class="btn" id="dbDetect">Detect my teams</button>
              <button class="btn" id="dbScan">Add teams on this page</button>
              <button class="btn" id="dbSeason" title="From one team, load every team in its season">List all club teams</button>
            </div>
            <div class="hint" id="dbModeHint"></div>
          </div>
          <div class="card">
            <label class="lab">Settings</label>
            <div class="nums">
              <div class="num"><small>Tight-travel if gap ≤ (min)</small><input type="number" id="dbBuffer" value="45" min="0" max="180" step="5"></div>
              <div class="num"><small>Game length (min)</small><input type="number" id="dbGameLen" value="50" min="10" max="180" step="5"></div>
              <div class="num"><small>Training length (min)</small><input type="number" id="dbTrainLen" value="60" min="10" max="240" step="5"></div>
            </div>
            <div class="row">
              <button class="btn primary" id="dbRun">Find conflicts</button>
              <button class="btn" id="dbRefresh">Refresh</button>
              <button class="btn" id="dbEmail" title="Copy a plain-English summary to paste into an email">Copy for email</button>
              <button class="btn" id="dbDiag" title="Report what the tool can see">Diagnostics</button>
            </div>
            <div class="prog" id="dbProg"></div>
          </div>
          <div id="dbResults"></div>
        </div>
      </aside>`;
    }

    function setMode(m) {
      state.mode = m;
      els.modeMine.classList.toggle("on", m === "mine");
      els.modeClub.classList.toggle("on", m === "club");
      const hint = root.querySelector("#dbModeHint");
      hint.innerHTML = m === "mine"
        ? "Scans the teams above and flags <b>your</b> clashes. Auto-filled with your teams; “Detect” or “Add teams on this page” to adjust."
        : "For the rec director: open a page that lists <b>every</b> team (a season’s team list), click <b>Add teams on this page</b>, then Find conflicts. Pulls each team’s staff and groups clashes <b>by coach</b>. Requires an account that can see those teams.";
    }

    function open() { overlay.classList.add("on"); }
    function close() { overlay.classList.remove("on"); }

    function teamIdsFromInput() {
      return [...new Set((els.teams.value || "").split(/[\s,]+/).map(function (s) { return s.trim().toLowerCase(); }).filter(function (s) { return /^[a-f0-9]{24}$/.test(s); }))];
    }
    function setTeamIds(ids) { els.teams.value = ids.join("\n"); }
    function readCfg() {
      function n(el, d) { const v = parseInt(el.value, 10); return isNaN(v) ? d : Math.max(0, v); }
      state.cfg = { buffer: n(els.buffer, 45), gameLen: n(els.gameLen, 50), trainLen: n(els.trainLen, 60) };
      return state.cfg;
    }
    function setBusy(b, msg) {
      state.busy = b;
      [els.run, els.refresh, els.detect, els.scan, els.season].forEach(function (e) { if (e) e.disabled = b; });
      if (msg != null) els.prog.textContent = msg;
    }

    function onScan() {
      const found = scrapeTeamIds();
      if (!found.length) { els.prog.textContent = "No team links found on this page. Open a team list page and try again."; return; }
      const merged = [...new Set(teamIdsFromInput().concat(found))];
      setTeamIds(merged);
      els.prog.textContent = "Added " + found.length + " team id(s) from this page (" + merged.length + " total).";
    }

    async function onDetect() {
      // Best-effort: harvest from the current page. (Reliable, no guessing.)
      const found = scrapeTeamIds();
      if (found.length) {
        setTeamIds([...new Set(teamIdsFromInput().concat(found))]);
        els.prog.textContent = "Found " + found.length + " team id(s) on this page. Add more by visiting other team pages, or Find conflicts.";
      } else {
        els.prog.textContent = "Couldn’t find teams on this page. Visit your teams list in Otto, then click “Add teams on this page”.";
      }
    }

    async function onListSeason() {
      if (state.busy) return;
      const seed = teamIdsFromInput()[0] || DEFAULT_TEAM_IDS[0];
      setBusy(true, "Looking up every team in the season…");
      try {
        const list = await enumerateSeasonTeams(seed);
        if (!list.length) { els.prog.textContent = "No teams returned — your login may not have season-wide access."; return; }
        const merged = [...new Set(teamIdsFromInput().concat(list.map(function (t) { return t.id; })))];
        setTeamIds(merged);
        setMode("club");
        els.prog.textContent = "Loaded " + list.length + " teams from the season (" + merged.length + " total). Now click Find conflicts.";
      } catch (e) {
        if (e.message === "SESSION_EXPIRED") els.prog.textContent = "Session token not captured yet — click a team in Otto, then try again.";
        else if (e.message === "NOT_LOGGED_IN") els.prog.textContent = "Not logged into Otto in this tab.";
        else els.prog.textContent = "Couldn’t list teams: " + e.message;
      } finally { setBusy(false, null); }
    }

    async function runNow() {
      if (state.busy) return;
      const ids = teamIdsFromInput();
      els.results.innerHTML = "";
      if (!ids.length) { els.prog.textContent = "Add at least one team id first."; return; }
      const cfg = readCfg();
      const byCoach = state.mode === "club";
      setBusy(true, "Loading 0/" + ids.length + " teams…");
      try {
        const data = await collect(ids, { byCoach: byCoach }, function (done, total) {
          els.prog.textContent = "Loading " + done + "/" + total + " teams…";
        });
        const analysis = analyze(data, cfg);
        state.last = { analysis: analysis, byCoach: byCoach, cfg: cfg };
        renderResults(analysis, data, byCoach);
        els.prog.textContent = "Done — " + analysis.totalEvents + " events across " + ids.length + " teams. Use “Copy for email” to send it to Chad.";
      } catch (e) {
        if (e.message === "NO_LIVE_TOKEN")
          showError("Couldn’t read your live Otto login yet. Click a team or navigate once inside Otto so the app loads data, then press <b>Refresh</b>. (Keep this tab on vsa.ottosport.ai.)");
        else if (e.message === "SESSION_EXPIRED")
          showError("Your Otto session token was rejected. Navigate once inside Otto (click a team) so the tool can grab your current login, then press <b>Refresh</b>. If that keeps happening, reload the page and try again.");
        else if (e.message === "NOT_LOGGED_IN")
          showError("You’re not logged into Otto in this tab. Log in, then press Refresh.");
        else showError("Something went wrong: " + esc(e.message));
        els.prog.textContent = "";
      } finally { setBusy(false, null); }
    }

    function showError(html) { els.results.innerHTML = '<div class="err">' + html + "</div>"; }

    function rng(e) { return fmtTime.format(new Date(e.startMs)) + "–" + fmtTime.format(new Date(e.endMs)); }
    function describe(cf) { return cf.kind === "overlap" ? "two places at once" : (cf.gapMin + " minute travel time"); }
    function gameLineText(e) { return "   - " + rng(e) + " - " + e.teamName + (e.type === "training" ? " (training)" : "") + " - " + (e.venue || "site TBD"); }  // TIME FIRST, dash-separated
    function conflictItems(conflicts, out) {
      let n = 1;
      conflicts.slice().sort(function (x, y) { return x.a.startMs - y.a.startMs; }).forEach(function (cf) {
        out.push(n + ". " + fmtDay.format(new Date(cf.a.startMs)) + " — " + describe(cf));
        out.push(gameLineText(cf.a));
        out.push(gameLineText(cf.b));
        out.push("");
        n++;
      });
    }
    function splitHardSoft(conflicts) {
      const hard = [], soft = [];
      conflicts.forEach(function (c) { (c.kind === "overlap" ? hard : soft).push(c); });
      return { hard: hard, soft: soft };
    }
    function buildEmailText(last) {
      const analysis = last.analysis, byCoach = last.byCoach;
      const affected = analysis.result.filter(function (r) { return r.conflicts.length; });
      const crit = analysis.result.reduce(function (n, r) { return n + r.crit; }, 0);
      const warn = analysis.result.reduce(function (n, r) { return n + r.warn; }, 0);
      const L = [];
      L.push("SCHEDULE CONFLICTS — " + fmtDay.format(new Date()));
      L.push("HARD = impossible, the coach can't be in both places.  SOFT = tight travel between parks — OK once in a while, a problem if it happens often.");
      L.push("");
      if (!affected.length) {
        L.push("GOOD NEWS: no conflicts found.");
        L.push("Checked " + analysis.result.length + (byCoach ? " coaches" : " schedule") + " and " + analysis.totalEvents + " events — nobody is double-booked, and there's enough time to travel between parks.");
        L.push("");
        L.push("(All times Eastern.)");
        return L.join("\n");
      }
      L.push("SUMMARY: " + crit + " HARD (impossible)" + (warn ? ", " + warn + " SOFT (tight travel)" : "") + (byCoach ? ", across " + affected.length + " coach(es)." : "."));
      L.push("");
      function renderUnit(conflicts) {
        const hs = splitHardSoft(conflicts);
        if (hs.hard.length) { L.push("HARD CONFLICTS — impossible:"); conflictItems(hs.hard, L); }
        if (hs.soft.length) { L.push("SOFT CONFLICTS — tight travel, watch the frequency:"); conflictItems(hs.soft, L); }
      }
      if (byCoach) {
        affected.slice().sort(function (x, y) { return (y.crit - x.crit) || (y.warn - x.warn) || x.coach.name.localeCompare(y.coach.name); }).forEach(function (r) {
          L.push("═════  " + r.coach.name + "  ═════");
          renderUnit(r.conflicts);
        });
      } else {
        const all = [];
        affected.forEach(function (r) { r.conflicts.forEach(function (c) { all.push(c); }); });
        renderUnit(all);
      }
      L.push("(All times Eastern. Checked with the Double-Booked schedule tool.)");
      return L.join("\n");
    }
    async function onEmail() {
      if (!state.last) { els.prog.textContent = "Click “Find conflicts” first, then Copy for email."; return; }
      const text = buildEmailText(state.last);
      try { await navigator.clipboard.writeText(text); toast("Copied — paste into your email"); }
      catch (e) { toast("Select the box below and copy (Ctrl/Cmd-C)"); }
      const old = root.querySelector("#dbEmailCard"); if (old) old.remove();
      els.results.insertAdjacentHTML("afterbegin",
        '<div class="card" id="dbEmailCard"><label class="lab">Email summary — copied to your clipboard. Paste it into an email to Chad.</label>' +
        '<textarea id="dbEmailBox" readonly style="min-height:220px">' + esc(text) + "</textarea></div>");
      const t = root.querySelector("#dbEmailBox"); if (t) { t.focus(); t.select(); }
    }

    async function runDiag() {
      const L = [];
      L.push("== Double-Booked diagnostics ==");
      L.push("extension code version: " + DB_VERSION + "   <-- must say 0.3.0-verbatim-auth");
      L.push("URL: " + location.href);
      L.push("world: " + (STATS.mainWorld ? "MAIN (good)" : "ISOLATED (patch won't see app!)"));
      L.push("fetch patched: " + (window.fetch && window.fetch.__dbPatched ? "yes" : "NO") + " | XHR patched: " + (window.XMLHttpRequest && window.XMLHttpRequest.prototype.__dbPatched ? "yes" : "NO"));
      L.push("app fetch calls seen: " + STATS.fetchCalls + " | app XHR opens seen: " + STATS.xhrOpens);
      L.push("");
      L.push("/_api requests intercepted: " + STATS.apiReqs.length);
      STATS.apiReqs.slice(-8).forEach(function (r) { L.push("  [" + r.t + "] hasAuth=" + r.hasAuth + " headers: " + (r.headers || []).join(",")); });
      L.push("");
      L.push("Live access token captured: " + (LIVE_AUTH ? "YES" : "NO"));
      if (LIVE_AUTH) {
        const sp = LIVE_AUTH.indexOf(" ");
        L.push("  auth scheme: " + (sp > 0 ? LIVE_AUTH.slice(0, sp) : "(none/raw)"));
        const raw = sp > 0 ? LIVE_AUTH.slice(sp + 1) : LIVE_AUTH;
        const exp = jwtExpMs(raw);
        L.push("  live token exp: " + (exp ? Math.round((exp - Date.now()) / 60000) + "m" : "unknown/not-a-JWT"));
      }
      const ck = getToken();
      L.push("Cookie dii_ua token: " + (ck ? ("present, exp " + (ck.exp ? Math.round((ck.exp - Date.now()) / 60000) + "m" : "unknown")) : "none"));
      if (ck) {
        try { const p = JSON.parse(b64url(ck.token.split(".")[1])); L.push("  cookie token claims: " + Object.keys(p).join(",")); L.push("  (typ=" + (p.typ || "?") + " aud=" + (p.aud || "?") + " scope=" + (p.scope ? "yes" : "no") + ")"); } catch (e) { L.push("  cookie token not a JWT"); }
      }
      L.push("");
      const testId = teamIdsFromInput()[0] || DEFAULT_TEAM_IDS[0];
      async function testCall(label, authHeader) {
        try {
          const headers = { "content-type": "application/json", "accept": "application/json", "Apollo-Require-Preflight": "true" };
          if (authHeader) headers["authorization"] = authHeader;
          const r = await fetch(API, { method: "POST", credentials: "include", __dbSelf: true, headers: headers, body: JSON.stringify({ operationName: "teamSchedules", query: Q_GAMES, variables: { seasonalTeamId: testId } }) });
          const txt = await r.text();
          L.push(label + ": HTTP " + r.status + " → " + txt.slice(0, 160));
        } catch (e) { L.push(label + ": ERROR " + e.message); }
      }
      L.push("Test calls to teamSchedules(" + testId + "):");
      if (LIVE_AUTH) await testCall("  A) live token", LIVE_AUTH);
      if (ck) await testCall("  B) cookie token", "Bearer " + ck.token);
      await testCall("  C) no Authorization (cookie session only)", null);
      els.results.innerHTML = '<div class="card"><label class="lab">Diagnostics — copy this to Claude</label><pre style="white-space:pre-wrap;word-break:break-word;font-family:ui-monospace,monospace;font-size:11.5px;margin:0;color:#15190f">' + esc(L.join("\n")) + "</pre></div>";
      els.prog.textContent = "Diagnostics ready — copy the box above.";
    }

    function pinSvg() { return '<svg viewBox="0 0 24 24" width="11" height="11" style="vertical-align:-1px;opacity:.6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.4"/></svg>'; }
    function gameLine(e) {
      const when = fmtDay.format(new Date(e.startMs)) + " · " + fmtTime.format(new Date(e.startMs)) + "–" + fmtTime.format(new Date(e.endMs));
      const opp = e.opponent ? ' <span class="opp">vs ' + esc(e.opponent) + "</span>" : "";
      const typ = '<span class="typ">' + (e.type === "training" ? "Training" : "Game") + "</span>";
      const venue = e.venue ? '<span class="gv">' + pinSvg() + " " + esc(e.venue) + "</span>" : '<span class="gv" style="color:#868d79">venue TBD</span>';
      return '<div class="g"><span class="gt">' + esc(when) + '</span><span class="gm"><b>' + esc(e.teamName) + "</b>" + opp + typ + "</span>" + venue + "</div>";
    }

    function renderResults(analysis, data, byCoach) {
      const withC = analysis.result.filter(function (r) { return r.conflicts.length; });
      const crit = analysis.result.reduce(function (n, r) { return n + r.crit; }, 0);
      const warn = analysis.result.reduce(function (n, r) { return n + r.warn; }, 0);
      const scanned = analysis.result.length;
      let html = '<div class="tiles">' +
        tile(byCoach ? "Coaches" : "Groups", scanned, "") +
        tile("Affected", withC.length, withC.length ? (crit ? "crit" : "warn") : "good") +
        tile("Overlaps", crit, crit ? "crit" : "good") +
        tile("Tight travel", warn, warn ? "warn" : "good") +
        tile("Events", analysis.totalEvents, "") + "</div>";

      if (!withC.length) {
        html += '<div class="empty"><div class="big">&#9989;</div><h3>No conflicts found</h3><p>Nobody here is double-booked or short on travel time.</p></div>';
        els.results.innerHTML = html; return;
      }
      html += '<div class="hd">Conflicts by ' + (byCoach ? "coach" : "your schedule") + "</div>";
      analysis.result.forEach(function (r) {
        if (!r.conflicts.length) return;
        const cls = r.crit ? "hc" : "hw";
        const uniq = [...new Set(r.events.map(function (e) { return e.teamName; }))];
        let badges = "";
        if (r.crit) badges += '<span class="badge crit">' + r.crit + " overlap" + (r.crit > 1 ? "s" : "") + "</span> ";
        if (r.warn) badges += '<span class="badge warn">' + r.warn + " tight</span>";
        const roleTxt = (r.coach.roles && r.coach.roles.length && !r.coach.implicit) ? ' <span class="roles">· ' + esc(r.coach.roles.join(", ")) + "</span>" : "";
        html += '<details class="coach ' + cls + '"' + (r.crit ? " open" : "") + '><summary><span class="stripe"></span><span class="sm">' +
          '<div class="cn">' + esc(r.coach.name) + roleTxt + '</div><div class="ct">' + uniq.map(function (t) { return '<span class="tm">' + esc(t) + "</span>"; }).join("") + "</div></span>" +
          '<span>' + badges + "</span></summary><div class=\"cbody\">";
        r.conflicts.sort(function (x, y) { return (x.a.startMs - y.a.startMs) || (x.sev === "crit" ? -1 : 1); });
        r.conflicts.forEach(function (cf) {
          const day = fmtDay.format(new Date(cf.a.startMs));
          let gap;
          if (cf.kind === "travel") gap = '<div class="gap">' + esc(cf.a.venue) + " → " + esc(cf.b.venue) + " · " + (cf.gapMin <= 0 ? "games overlap the drive" : "only " + cf.gapMin + " min between parks (tight if ≤ " + state.cfg.buffer + ")") + "</div>";
          else { const gm = Math.round((Math.min(cf.a.endMs, cf.b.endMs) - Math.max(cf.a.startMs, cf.b.startMs)) / 60000); gap = '<div class="gap">overlaps by ' + gm + " min</div>"; }
          html += '<div class="cf ' + cf.sev + '"><div class="t">' + esc(cf.note) + '</div><div class="when">' + esc(day) + "</div>" + gameLine(cf.a) + gameLine(cf.b) + gap + "</div>";
        });
        html += "</div></details>";
      });
      if (data.notes && data.notes.length) {
        const real = data.notes.filter(function (n) { return /fail/i.test(n); });
        if (real.length) html += '<div class="hint">Some teams didn’t fully load: ' + esc(real.slice(0, 6).join(" · ")) + "</div>";
      }
      els.results.innerHTML = html;
    }
    function tile(k, v, cls) { return '<div class="tile ' + (cls || "") + '"><div class="k">' + esc(k) + '</div><div class="v">' + v + "</div></div>"; }

    return { mount: mount, open: open };
  })();

  window.__doubleBooked__ = App;
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", App.mount, { once: true });
  else App.mount();
})();
