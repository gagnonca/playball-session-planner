# Double-Booked — Otto Coach Conflicts (Chrome/Edge extension)

Finds coaches booked for two games at once, or without enough time to drive between
parks, by reading your VSA Otto schedule live. Runs entirely in your browser; no data
leaves the page.

## Install (takes 30 seconds)

1. Open **chrome://extensions** (or **edge://extensions**).
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked** and pick this `double-booked-extension` folder.
4. Go to **https://vsa.ottosport.ai** and log in. A green **⚽ Conflicts** button
   appears at the bottom-right of the page.

To update later: replace the folder's files, then click the ↻ refresh icon on the
extension's card in chrome://extensions.

## Use it — your own teams

1. Click **⚽ Conflicts**. The panel opens with your team IDs pre-filled.
2. Click **Find conflicts**. You'll see every clash across your teams, with times,
   parks, and the overlap / travel gap.
3. Clicked into the wrong week or changed the schedule? Hit **Refresh** — it re-reads
   Otto live (no page reload, no login juggling).

Not your teams pre-filled, or want to add one? Open that team's page in Otto and click
**Add teams on this page**, or paste its ID (from the team-page URL
`…/team/THIS_PART`) into the box.

## Use it — whole club, by coach (for the rec director)

1. Switch the toggle to **Whole club (by coach)**.
2. In Otto, open a page that lists **every** team (a season's team list).
3. Click **Add teams on this page** to harvest all their IDs.
4. Click **Find conflicts**. For each team it pulls the staff roster and groups every
   clash **by coach**, so you see exactly which coach is double-booked and where.

This mode only returns teams your Otto account can see — run it under the director /
registrar / scheduler login for full club coverage.

## Settings

- **Travel buffer** — minimum minutes needed between games at *different* parks
  (below this = a tight-travel warning). Default 30.
- **Game / training length** — used only when Otto doesn't supply a duration.

## What it flags

- 🔴 **Overlap** — two of a coach's teams playing/training at the same time.
- 🟠 **Tight travel** — back-to-back games at different parks with less gap than the
  buffer.

Same-park back-to-back games are *not* flagged (no travel needed).
